CYPERHACK-DDOS coded by hphongdev
contact me ? 
telegram: @vilgaxinjector
facebook: fb.com/leHongphong.user


INSTALLATION
__________________________________
npm i cloudscraper
npm i chalk
npm i useragents
npm i fake-useragents
__________________________________

#PUT IT IN YOUR VPS AND ENJOY IT🥰